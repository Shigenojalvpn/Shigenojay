clear
neofetch
cat /root/log-install.txt
echo -e ""
read -n 1 -s -r -p "  Press any key to back on menu"
menu
esac
